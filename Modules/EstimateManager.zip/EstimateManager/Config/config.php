<?php

return [
    'name' => 'EstimateManager'
];
