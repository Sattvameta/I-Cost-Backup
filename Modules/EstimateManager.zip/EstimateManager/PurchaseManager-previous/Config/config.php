<?php

return [
    'name' => 'PurchaseManager'
];
