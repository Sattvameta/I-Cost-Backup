<?php

namespace Modules\EstimateManager\Repositories;

use Modules\EstimateManager\Entities\Activity;
use Modules\EstimateManager\Entities\MainActivity;
use Modules\EstimateManager\Entities\SubActivity;

class EstimateRepository{

    /**
     * Handle internal calculation.
     */
    public function handleInternalCalculation($mainActivity, $subActivity = null, $activity = null){
        
    }

}
