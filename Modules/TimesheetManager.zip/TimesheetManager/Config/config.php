<?php

return [
    'name' => 'TimesheetManager'
];
