<?php

return [
    'name' => 'CarbonDatabase'
];
