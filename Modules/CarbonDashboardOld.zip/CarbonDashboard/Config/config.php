<?php

return [
    'name' => 'CarbonDashboard'
];
